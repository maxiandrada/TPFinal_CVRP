# TPFinal_CVRP
A-n61-k9 -> Se estanca en 13.3% en 1min (empieza con Vecino Cercano)
A-n53-k7 -> Se estanco en 10.9% en 2min
